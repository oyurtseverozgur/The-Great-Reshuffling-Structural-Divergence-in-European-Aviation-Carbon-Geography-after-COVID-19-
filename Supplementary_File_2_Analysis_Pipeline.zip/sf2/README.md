# Supplementary File 2 - Reproducible analysis pipeline

Article: "The Great Reshuffling: Post-Pandemic Redistribution of European Aviation CO2 across the Emissions-Trading Boundary (2010-2026)", Journal of Aviation Technology and Engineering (revised submission R1).

## Inputs
* `data/co2_emmissions_by_state_2010.csv` ... `_2026.csv`: EUROCONTROL "CO2 emissions by State - SET" files
  (https://ansperformance.eu/reference/dataset/emissions/), downloaded 4 July 2026 (January 2010 - May 2026). Not redistributed; download and place in `data/`.
* `data/wb_macro.csv`: World Bank WDI extract (NY.GDP.PCAP.KD, SP.POP.TOTL; 2010, 2019, 2022, 2025), retrieved 26 September 2026.

## Run (Python >= 3.10; pandas, numpy, scipy, statsmodels, matplotlib, openpyxl)
    mkdir -p out fig
    python analysis.py        # panels, sigma/beta, Theil, Spearman, robustness windows   -> out/results.json
    python macro.py           # macro-conditioned beta, per-capita sigma/beta             -> out/macro_results.json
    python tab4_t.py          # Table 4 / A3 with HC3 errors and t reference distribution -> out/table4_t.json
    python trend.py           # trend-path diagnostics (Table 2)                          -> out/trend_results.json
    python revision_jate.py   # HC3 CIs, influence, break sensitivity, leave-one-out,
                              # income-based grouping, maturity control (Tables 3, 5, A2, A4) -> out/revision_results.json
    python make_figs.py       # figures (PNG 300 dpi, TIFF 600 dpi)                      -> fig/

In the code, "Core" denotes ETS-participating states and "Periphery" non-ETS states.
Output file names in fig/: Fig1 (Figure 1), Fig2 (Figure 2), Fig5 (manuscript Figure 3), Fig3 (Figure 4), Fig4 (Figure 5).

## Key design choices
* All merges are keyed on STATE_NAME: STATE_CODE is not unique (LY = Montenegro and Serbia; LS = Liechtenstein and Switzerland).
* Monaco and Liechtenstein are dropped; the balanced panel excludes Latvia, Georgia and Estonia (late entrants).
* January 2020 is pre-pandemic; break tests exclude January 2021 and allow level and slope shifts from 2022.
* The Canary Islands are excluded from WDI-based regressions (no separate national statistics).
